package net.sourceforge.jwbf.contentRep.mw;

/**
 * Representaion of MediaWiki version.
 * @author Thomas Stock
 *
 */
public enum Version {
MW1_09, MW1_10, MW1_11, MW1_12, MW1_13, MW1_14, MW1_15, UNKNOWN;
}
